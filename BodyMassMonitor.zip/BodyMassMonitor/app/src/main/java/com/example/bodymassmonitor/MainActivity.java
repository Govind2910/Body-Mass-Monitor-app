package com.example.bodymassmonitor;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.ContextCompat;  // Import ContextCompat for resource compatibility

public class MainActivity extends AppCompatActivity {

    private EditText heightEditText;
    private EditText weightEditText;
    private TextView resultTextView;
    private Button calculateButton;
    private ImageView logoImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        heightEditText = findViewById(R.id.heightEditText);
        weightEditText = findViewById(R.id.weightEditText);
        resultTextView = findViewById(R.id.resultTextView);
        calculateButton = findViewById(R.id.calculateButton);
        logoImageView = findViewById(R.id.logoImageView);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateBMI();
            }
        });
    }

    private void calculateBMI() {
        String heightStr = heightEditText.getText().toString();
        String weightStr = weightEditText.getText().toString();

        if (!heightStr.isEmpty() && !weightStr.isEmpty()) {
            float height = Float.parseFloat(heightStr) / 100; // convert height to meters
            float weight = Float.parseFloat(weightStr);

            float bmi = weight / (height * height);

            displayBMIResult(bmi);
        } else {
            Toast.makeText(this, "Please enter both height and weight", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayBMIResult(float bmi) {
        String bmiResult;
        if (bmi < 18.5) {
            bmiResult = "Underweight";
        } else if (bmi >= 18.5 && bmi < 25) {
            bmiResult = "Normal Weight";
        } else if (bmi >= 25 && bmi < 30) {
            bmiResult = "Overweight";
        } else {
            bmiResult = "Obese";
        }

        String resultMessage = String.format("Your BMI: %.1f\n%s", bmi, bmiResult);

        // Retrieve health implications based on the BMI category
        String healthImplication = getHealthImplication(bmiResult);
        if (healthImplication != null) {
            resultMessage += "\n\nHealth Implications:\n" + healthImplication;
        }

        // Set the result message to the TextView
        resultTextView.setText(resultMessage);

        // Update text color and background color programmatically
        resultTextView.setTextColor(ContextCompat.getColor(this, R.color.dark_text_color));
        resultTextView.setBackgroundColor(ContextCompat.getColor(this, R.color.light_background_color));
    }

    private String getHealthImplication(String bmiResult) {
        switch (bmiResult) {
            case "Underweight":
                return "Health implications of being underweight may include nutritional deficiencies and weakened immune system.";
            case "Normal Weight":
                return "You are in a healthy weight range. Maintain a balanced diet and regular exercise.";
            case "Overweight":
                return "Health implications of being overweight may include increased risk of heart disease, diabetes, and joint problems.";
            case "Obese":
                return "Health implications of obesity may include higher risk of cardiovascular diseases, type 2 diabetes, and certain cancers.";
            default:
                return null;
        }
    }
}
